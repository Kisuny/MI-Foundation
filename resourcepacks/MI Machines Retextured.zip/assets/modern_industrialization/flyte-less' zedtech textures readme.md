ZedTech was created by Zerrens
https://forum.industrial-craft.net/core/user/12229-zerrens/

Zedtech MI was adapted from textures made for GTCEu in this project
https://legacy.curseforge.com/minecraft/texture-packs/zederrian-technology-for-gtceu

Porting and edits were done by Flyte-less

Licensed under CC BY-NC-SA 4.0
https://creativecommons.org/licenses/by-nc-sa/4.0/
